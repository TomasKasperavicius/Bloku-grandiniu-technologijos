int main(int argc, char* argv[])
{
    auto a = 1 + 2;
    return 0;
}
